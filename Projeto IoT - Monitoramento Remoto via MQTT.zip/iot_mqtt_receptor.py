
import paho.mqtt.client as mqtt
import json

# Limites
LIMITE_TEMP = 35.0
HISTERESE = 2.0
LIMITE_POTENCIA = 10.0

ventilador_ligado = False

def on_connect(client, userdata, flags, rc):
    print("Conectado ao broker com código:", rc)
    client.subscribe("sprint/iot/sensores")

def on_message(client, userdata, msg):
    global ventilador_ligado

    dados = json.loads(msg.payload.decode())
    temperatura = dados["temperatura"]
    tensao = dados["tensao"]
    corrente = dados["corrente"]
    potencia = dados["potencia"]

    print(f"Temperatura: {temperatura} °C")
    print(f"Tensão: {tensao} V")
    print(f"Corrente: {corrente} A")
    print(f"Potência: {potencia} W")

    # Ações automáticas simuladas
    if not ventilador_ligado and temperatura >= LIMITE_TEMP:
        ventilador_ligado = True
        print("→ Temperatura acima de 35°C - Ventilador ativado")
    elif ventilador_ligado and temperatura <= (LIMITE_TEMP - HISTERESE):
        ventilador_ligado = False
        print("→ Temperatura abaixo do limite - Ventilador desligado")

    if potencia > LIMITE_POTENCIA:
        print("→ Potência acima de 10W - Relé ativado")
    else:
        print("→ Potência normal - Relé desligado")

# Conexão com o broker
client = mqtt.Client()
client.on_connect = on_connect
client.on_message = on_message

client.connect("broker.hivemq.com", 1883, 60)
client.loop_forever()
