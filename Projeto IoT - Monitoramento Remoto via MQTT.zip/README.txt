Após mais de uma semana de estudo para conseguir montar o projeto conforme solicitado, seguem os arquivos .ino e .py


Alunos participantes: 

Taysir Fauzi Ali 
RM: 564884

Rafael de Medeiros Cordeiro 
RM:562167

Carlos Augusto Pires da Silva 
RM: 564927

Felipe Paula Burba Molonhoni
RM: 564395

Mateus Francisco Comim Magalhaes
RM:562119